@echo off
cd /d "%~dp0"
set "PARI_OPEN_PATH=/editor"
runtime\node.exe server.cjs
pause
