@echo off
cd /d "%~dp0"
runtime\node.exe server.cjs
pause
