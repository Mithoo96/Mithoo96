#!/bin/bash
cd "$(dirname "$0")"
./runtime/node server.cjs
read -r -p "Press Return to close this window."
