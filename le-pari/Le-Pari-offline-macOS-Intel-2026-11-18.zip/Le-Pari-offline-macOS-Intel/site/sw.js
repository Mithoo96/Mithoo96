/* global self, caches */
importScripts("/precache.js");

const PREFIX = "pari-presentation-";
const { version, urls } = self.PARI_PRECACHE;
const CACHE = PREFIX + version;
const assets = new Set(urls);
const pages = new Set(["/", "/archival", "/presenter", "/editor"]);

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(
      urls.map(url => new Request(url, { cache: "reload" })),
    )).then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith(PREFIX) && key !== CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  if (pages.has(url.pathname) && event.request.mode === "navigate") {
    event.respondWith(fetch(event.request).catch(async () => (
      (await caches.open(CACHE)).match(url.pathname)
    )));
  } else if (!pages.has(url.pathname) && assets.has(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE);
      return (await cache.match(url.pathname)) ?? fetch(event.request);
    })());
  }
});
