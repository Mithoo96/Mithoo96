const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { spawn } = require("node:child_process");

const root = path.join(__dirname, "site");
const port = Number(process.env.PARI_PORT || 4178);
const destination = process.env.PARI_OPEN_PATH === "/editor" ? "/editor" : "/archival";
const url = `http://127.0.0.1:${port}${destination}`;

function openBrowser() {
  console.log(`Le Pari du Dialogue is ready at ${url}`);
  if (process.env.PARI_NO_OPEN === "1") return;
  const command = process.platform === "darwin" ? "open" : process.platform === "win32" ? "cmd.exe" : "xdg-open";
  const args = process.platform === "win32" ? ["/c", "start", "", url] : [url];
  const browser = spawn(command, args, { stdio: "ignore" });
  browser.on("error", () => console.log("Open the address above in your browser."));
}
const types = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".webmanifest": "application/manifest+json",
  ".css": "text/css; charset=utf-8", ".json": "application/json",
  ".woff": "font/woff", ".woff2": "font/woff2",
  ".webp": "image/webp", ".png": "image/png", ".svg": "image/svg+xml",
  ".wav": "audio/wav", ".ico": "image/x-icon",
};

const server = http.createServer(async (request, response) => {
  const url = new URL(request.url, "http://127.0.0.1");
  if (url.pathname === "/api/offline-status") {
    response.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
    response.end(JSON.stringify({ application: "le-pari-offline-v1" }));
    return;
  }
  if (url.pathname === "/api/speech") {
    response.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
    response.end(JSON.stringify({ available: false }));
    return;
  }
  if (request.method !== "GET" && request.method !== "HEAD") {
    response.writeHead(405).end();
    return;
  }
  const route = { "/": "/index.html", "/archival": "/index.html", "/presenter": "/presenter.html", "/editor": "/editor.html" };
  let file;
  try {
    file = path.resolve(root, "." + (route[url.pathname] || decodeURIComponent(url.pathname)));
  } catch {
    response.writeHead(400).end();
    return;
  }
  if (!file.startsWith(root + path.sep)) {
    response.writeHead(403).end();
    return;
  }
  try {
    const stat = await fs.promises.stat(file);
    if (!stat.isFile()) throw new Error("Not a file");
    response.writeHead(200, {
      "Content-Type": types[path.extname(file)] || "application/octet-stream",
      "Content-Length": stat.size,
      "Cache-Control": "no-cache",
      "X-Content-Type-Options": "nosniff",
    });
    if (request.method === "HEAD") response.end();
    else fs.createReadStream(file).pipe(response);
  } catch {
    response.writeHead(404).end("File unavailable");
  }
});

server.on("error", async error => {
  if (error.code === "EADDRINUSE") {
    const existing = await fetch(`http://127.0.0.1:${port}/api/offline-status`, {
      signal: AbortSignal.timeout(1500),
    }).then(response => response.json(), () => null).catch(() => null);
    if (existing?.application === "le-pari-offline-v1") {
      openBrowser();
      return;
    }
  }
  console.error(error.code === "EADDRINUSE" ? `Port ${port} is already in use. Close the other local server and try again.` : error.message);
  process.exitCode = 1;
});
server.listen(port, "127.0.0.1", () => {
  openBrowser();
  console.log("Keep this window open during the presentation. Press Ctrl+C to stop.");
});
