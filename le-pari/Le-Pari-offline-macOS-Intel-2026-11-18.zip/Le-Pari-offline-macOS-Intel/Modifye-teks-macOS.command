#!/bin/bash
cd "$(dirname "$0")"
PARI_OPEN_PATH=/editor ./runtime/node server.cjs
read -r -p "Press Return to close this window."
